#!/usr/bin/env python3
"""
把 jar 中所有 .class 的 major_version 改为 Java 17 (61)。
警告：这只是改 header，不保证类能在 Java17 上正常运行。
用法: python fix_class_version.py input.jar output.jar
"""
import sys, zipfile, shutil, os

TARGET_MAJOR = 61  # Java 17

def fix_jar(inpath, outpath):
    with zipfile.ZipFile(inpath, 'r') as zin:
        with zipfile.ZipFile(outpath, 'w') as zout:
            for item in zin.infolist():
                data = zin.read(item.filename)
                if item.filename.endswith('.class') and len(data) >= 8 and data[0:4] == b'\xCA\xFE\xBA\xBE':
                    ba = bytearray(data)
                    # class file: bytes 4-5 minor, bytes 6-7 major (big-endian)
                    ba[6] = (TARGET_MAJOR >> 8) & 0xFF
                    ba[7] = TARGET_MAJOR & 0xFF
                    zout.writestr(item, bytes(ba))
                else:
                    zout.writestr(item, data)

if __name__ == '__main__':
    if len(sys.argv) != 3:
        print("usage: python fix_class_version.py in.jar out.jar")
        sys.exit(1)
    inp, outp = sys.argv[1], sys.argv[2]
    if not os.path.exists(inp):
        print("input jar not found:", inp); sys.exit(2)
    print("Backing up original to", inp + ".bak")
    shutil.copy2(inp, inp + ".bak")
    fix_jar(inp, outp)
    print("Wrote", outp)
