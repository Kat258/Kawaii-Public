import re
import os

def update_config():
    changelog_path = r"..\ZKM-21.0.0-Cracked\ZKM 21.0.0\ChangeLog.txt"
    config_path = "config.xml"
    
    if not os.path.exists(changelog_path):
        print(f"Error: {changelog_path} not found.")
        return
    
    if not os.path.exists(config_path):
        print(f"Error: {config_path} not found.")
        return

    # Find all obfuscated class names under dev.kizuna.mod.modules.impl and dev.kizuna.core
    # Also include the main class dev.kizuna.Kawaii
    # Format: Class: ... dev.kizuna.xxxx => dev.kizuna.m7601...
    pattern_impl = re.compile(r"Class:.*?(dev\.kizuna\.mod\.modules\.impl\..*?)\s+=>\s+(dev\.kizuna\.\S+)")
    pattern_core = re.compile(r"Class:.*?(dev\.kizuna\.core\..*?)\s+=>\s+(dev\.kizuna\.\S+)")
    pattern_main = re.compile(r"Class:.*?(dev\.kizuna\.Kawaii)\s+=>\s+(dev\.kizuna\.\S+)")
    
    obfuscated_names = set()
    
    with open(changelog_path, 'r', encoding='utf-8') as f:
        content = f.read()
        
        # Match modules implementation classes
        matches_impl = pattern_impl.findall(content)
        for old_name, new_name in matches_impl:
            if '$' not in old_name:
                obfuscated_names.add(new_name)
        
        # Match core classes
        matches_core = pattern_core.findall(content)
        for old_name, new_name in matches_core:
            if '$' not in old_name:
                obfuscated_names.add(new_name)
        
        # Match main Kawaii class
        match_main = pattern_main.search(content)
        if match_main:
            obfuscated_names.add(match_main.group(2))
            print(f"Added main class: {match_main.group(1)} => {match_main.group(2)}")
    
    if not obfuscated_names:
        print("No matching classes found in ChangeLog.txt")
        return

    print(f"Found {len(obfuscated_names)} classes to include.")

    # Read config.xml
    encoding_to_use = 'utf-8'
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            xml_content = f.read()
    except UnicodeDecodeError:
        encoding_to_use = 'utf-16'
        with open(config_path, 'r', encoding='utf-16') as f:
            xml_content = f.read()

    # Prepare the new include block
    include_entries = []
    for name in sorted(list(obfuscated_names)):
        include_entries.append(f'\t\t<match className="{name}"/>')
    
    # Replace the old <include> block more robustly
    start_tag = "<include>"
    end_tag = "</include>"
    
    if start_tag in xml_content and end_tag in xml_content:
        start_idx = xml_content.find(start_tag)
        end_idx = xml_content.find(end_tag) + len(end_tag)
        
        # Keep the indentation of the <include> tag
        prefix = ""
        idx = start_idx - 1
        while idx >= 0 and xml_content[idx] in (' ', '\t'):
            prefix = xml_content[idx] + prefix
            idx -= 1
        
        new_include_content = f"{start_tag}\n" + "\n".join(include_entries) + f"\n{prefix}{end_tag}"
        xml_content = xml_content[:start_idx] + new_include_content + xml_content[end_idx:]
    else:
        print("Could not find <include> block in config.xml")
        return

    # Write back
    with open(config_path, 'w', encoding=encoding_to_use) as f:
        f.write(xml_content)
    
    print("Successfully updated config.xml with obfuscated class names.")

if __name__ == "__main__":
    update_config()
