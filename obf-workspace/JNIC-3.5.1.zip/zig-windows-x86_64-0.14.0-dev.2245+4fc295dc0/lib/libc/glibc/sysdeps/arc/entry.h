#ifndef __ASSEMBLY__
extern void __start (void) attribute_hidden;
#endif

#define ENTRY_POINT __start
